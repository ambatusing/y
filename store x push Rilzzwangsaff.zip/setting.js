/* SC 𝖡𝖸 : GRIMS MODZ
𝖪𝖠𝖫𝖮 𝖬𝖠𝖴 𝖱𝖤𝖢𝖮𝖣𝖤, 𝖳𝖠𝖦 𝖦𝖴𝖠 𝖸𝖠𝖧
𝖶𝖠 : 𝟢𝟪95370994581 , 083134555113 , 62895323106400
𝖨𝖦 : @grimshosting
𝖸𝖳 : Grims.Hosting
𝖦𝗋𝗈𝗎𝗉 : https://chat.whatsapp.com/KEPEFjcUzVG2d9IOeDGj0Q
*/

const fs = require('fs')
const chalk = require('chalk')
global.owner = "628567252722"
global.namabot = "STOREXPUSH"
global.botname = "𝖡𝗈𝗍 RILZZZ"
global.autoJoin = false
global.codeInvite = "FwtMxovJqW3Jj55x524hjT"
global.thumb = fs.readFileSync("./thumb.png")
global.sessionName = 'sesidimz' //Gausah Juga
global.bugthomz = fs.readFileSync("./dimzbug.png")
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = ""
global.author = "𝖲𝗍𝗂𝗄𝖾𝗋 𝖻𝗒 DERIL STORE"

global.namastore = "PONG STORE"
global.nodana = "082146418535"
global.qris = "https://telegra.ph/file/18cf73b03c11138eb397f.jpg"

global.domain = 'https://irsanreal.panelstore.xyz' // Isi Domain Lu
global.apikey = 'ptla_lSFSlFMSg6rLnNY8NKusowiu1x3cfvWZfbTX6GfM4S3' // Isi Apikey Plta Lu
global.capikey = 'ptlc_DL08MCSCkVIVJFjtlZ2bP9tMT4rOz6NbSBqK9vDUukQ' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

global.antilink = false

const mess = {
   wait: "𝖶𝖺𝗂𝗍 𝗉𝗋𝗈𝗌𝖾𝗌 𝗆𝖺𝗌, 𝗁𝖺𝗋𝖺𝗉 𝗌𝖺𝖻𝖺𝗋...",
   success: "𝖲𝗎𝗄𝗌𝖾𝗌 𝗆𝖺𝗌...",
   save: "𝖲𝖺𝗏𝖾 𝖼𝗈𝗇𝗍𝖺𝖼𝗍 𝖻𝖾𝗋𝗁𝖺𝗌𝗂𝗅...",
   on: "𝖮𝖭𝖫𝖨𝖭𝖤", 
   off: "𝖮𝖥𝖥𝖫𝖨𝖭𝖤",
   query: {
       text: "Teks Nya Mana Kak?",
       link: "Link Nya Mana Kak?",
   },
   error: {
       fitur: "Mohon Maaf Kak Fitur Eror Silahkan Chat Developer Bot Agar Bisa Segera Diperbaiki",
   },
   only: {
       group: "𝖬𝖺𝖺𝖿,𝖿𝗂𝗍𝗎𝗋 𝗂𝗇𝗂 𝗁𝖺𝗇𝗒𝖺 𝖽𝖺𝗉𝖺𝗍 𝖽𝗂𝗀𝗎𝗇𝖺𝗄𝖺𝗇 𝖽𝗂𝖽𝖺𝗅𝖺𝗆 𝗀𝗋𝗈𝗎𝗉...",
       private: " 𝖬𝖺𝖺𝖿,𝖿𝗂𝗍𝗎𝗋 𝗂𝗇𝗂 𝗁𝖺𝗇𝗒𝖺 𝖽𝖺𝗉𝖺𝗍 𝖽𝗂𝗀𝗎𝗇𝖺𝗄𝖺𝗇 𝖽𝗂𝗉𝗋𝗂𝗏𝖺𝗍𝖾 𝖼𝗁𝖾𝗍...",
       owner: "𝖬𝖺𝖺𝖿 𝖿𝗂𝗍𝗎𝗋 𝗂𝗇𝗂 𝗄𝗁𝗎𝗌𝗎𝗌 𝗈𝗐𝗇𝖾𝗋 𝗌𝖺𝗃𝖺...",
       admin: "𝖬𝖺𝖺𝖿 𝖿𝗂𝗍𝗎𝗋 𝗂𝗇𝗂 𝗄𝗁𝗎𝗌𝗎𝗌 𝖺𝖽𝗆𝗂𝗇 DERIL STORE...",
       badmin: "𝖬𝖺𝖺𝖿,𝖿𝗂𝗍𝗎𝗋 𝗂𝗇𝗂 𝗍𝗂𝖽𝖺𝗄 𝖽𝖺𝗉𝖺𝗍 𝖽𝗂𝗀𝗎𝗇𝖺𝗄𝖺𝗇 𝖽𝗂𝗄𝖺𝗋𝖾𝗇𝖺𝗄𝖺𝗇 𝖻𝗈𝗍 𝖻𝗎𝗄𝖺𝗇 𝖺𝖽𝗆𝗂𝗇...",
       premium: "𝖬𝖺𝖺𝖿,𝗄𝖺𝗆𝗎 𝖻𝗎𝗄𝖺𝗇 𝗎𝗌𝖾𝗋 𝗉𝗋𝖾𝗆𝗂𝗎𝗆,𝗎𝗇𝗍𝗎𝗄 𝗆𝖾𝗆𝖻𝖾𝗅𝗂 𝖺𝗄𝗌𝖾𝗌 𝗌𝗂𝗅𝖺𝗁𝗄𝖺𝗇 𝗄𝖾𝗍𝗂𝗄 .𝗈𝗐𝗇𝖾𝗋 𝗎𝗇𝗍𝗎𝗄 𝗆𝖾𝗇𝗀𝗁𝗎𝖻𝗎𝗇𝗀𝗂 𝗈𝗐𝗇𝖾𝗋",
   }
}

global.mess = mess
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})